public class Circle implements Shape {
    private double radius;
    private String color;

    public Circle(double radius, String color) {
        radius = radius;
        color = color;
    }

    