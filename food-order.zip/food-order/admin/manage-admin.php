<?php include('partials/menu.php'); ?>


        <!--Main Content Section Starts-->
        <div class="main-content">
             <div class="wrapper">
                  <h1>Manage Admin</h1>

                  <br/>

                  <?php
                       if(isset($_SESSION['add']))
                       {
                        echo $_SESSION['add'];//Displaying Session Message
                        unset($_SESSION['add']);//REmoving Session Message

                       }
                   ?>
                   <br><br><br>
                  <!--Button to Add Admin-->
                  <a href="add-admin.php" class="btn-primary">Add Admin</a>
                  <br/><br/><br/>



                  <table class="tbl-full">
                    <tr>
                        <th>S.N</th>
                        <th>Full Name</th>
                        <th>Username</th>
                        <th>Actions</th>
                 </tr>

                 <?php
                 //Query to Get all Admin
                 $sql = "SELECT * FROM tbl_admin";
                 //Execute the Query
                 $res = mysqli_query($conn,$sql);

                 //Check whether the Query is Executed of Not
                 if($res=TRUE)
                 {
                  //Count Rows to Check whether we have data in database or not
                  $rows = mysqli_num_rows($res);//Function to get all the rows in database

                  //Check the num of rows
                  if($rows>0)
                  {
                     //We have data in database
                  }
                  else
                  {
                     //we do not have data in database

                  }
                 }


                 ?>



                 <tr>
                    <td>1.</td>
                    <td>S Devi</td>
                    <td>devi</td>
                    <td>
                        <a href="#" class="btn-secondary">Update Admin</a>
                        <a href="#" class="btn-danger">Delete Admin</a>
                    </td>

                 </tr>
                 <tr>
                    <td>2.</td>
                    <td>S Devi</td>
                    <td>devi</td>
                    <td>
                    <a href="#" class="btn-secondary">Update Admin</a>
                    <a href="#" class="btn-danger">Delete Admin</a>
                    </td>

                 </tr>
                 <tr>
                    <td>3.</td>
                    <td>S Devi</td>
                    <td>devi</td>
                    <td>
                    <a href="#" class="btn-secondary">Update Admin</a>
                    <a href="#" class="btn-danger">Delete Admin</a>
                    </td>

                 </tr>
                    
              </table>

                  
             </div>
            

        </div>
        <!--Main content  Section Ends-->
<?php include('partials/footer.php'); ?>

